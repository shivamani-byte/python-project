"""Database test cases: normal, invalid, empty, boundary, and DB errors.

Run:  python test_db.py
Every test cleans up after itself, so the sample data is left untouched.
"""
from decimal import Decimal
from db import fetch_all, fetch_one, execute, health_check, DatabaseError

passed = failed = 0


def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print(f"  PASS  {name}")
    else:
        failed += 1
        print(f"  FAIL  {name}")


def expect_error(name, query, params):
    try:
        execute(query, params)
        check(name, False)
    except DatabaseError:
        check(name, True)


INSERT = ("INSERT INTO expenses (expense_date, category_id, amount, description) "
          "VALUES (%s, %s, %s, %s)")

print("\n[Normal input]")
check("health check passes", health_check())
check("tables have sample data",
      fetch_one("SELECT COUNT(*) AS n FROM expenses")["n"] > 0
      and fetch_one("SELECT COUNT(*) AS n FROM categories")["n"] > 0)
new_id, _ = execute(INSERT, ("2026-10-22", 1, Decimal("123.45"), "TEST ROW"))
row = fetch_one("SELECT * FROM expenses WHERE expense_id = %s", (new_id,))
check("insert + read back", row and row["amount"] == Decimal("123.45"))
execute("UPDATE expenses SET amount = %s WHERE expense_id = %s", (Decimal("200.00"), new_id))
check("update works", fetch_one("SELECT amount FROM expenses WHERE expense_id=%s", (new_id,))["amount"] == Decimal("200.00"))
execute("DELETE FROM expenses WHERE expense_id = %s", (new_id,))
check("delete works", fetch_one("SELECT * FROM expenses WHERE expense_id=%s", (new_id,)) is None)
check("JOIN categories/expenses works",
      len(fetch_all("SELECT e.expense_id, c.category_name FROM expenses e "
                    "JOIN categories c ON c.category_id = e.category_id")) > 0)

print("\n[Invalid input - must be rejected by the database]")
expect_error("zero amount rejected", INSERT, ("2026-10-22", 1, 0, "bad"))
expect_error("negative amount rejected", INSERT, ("2026-10-22", 1, -50, "bad"))
expect_error("unknown category rejected (foreign key)", INSERT, ("2026-10-22", 9999, 10, "bad"))
expect_error("invalid date rejected", INSERT, ("not-a-date", 1, 10, "bad"))
expect_error("NULL amount rejected", INSERT, ("2026-10-22", 1, None, "bad"))
expect_error("duplicate category name rejected",
             "INSERT INTO categories (category_name) VALUES (%s)", ("Food",))
expect_error("deleting a category in use is blocked",
             "DELETE FROM categories WHERE category_id = %s", (1,))

expect_error("negative monthly budget rejected",
             "INSERT INTO budgets (budget_month, amount) VALUES (%s, %s)", ("2030-01", -5))
check("budgets table readable", fetch_one("SELECT COUNT(*) AS n FROM budgets")["n"] >= 1)

print("\n[Empty dataset]")
check("date range with no records returns empty list",
      fetch_all("SELECT * FROM expenses WHERE expense_date BETWEEN %s AND %s",
                ("2000-01-01", "2000-01-31")) == [])
check("category with no expenses returns empty list",
      fetch_all("SELECT * FROM expenses e JOIN categories c ON c.category_id=e.category_id "
                "WHERE c.category_name = %s", ("Other",)) == [])

print("\n[Boundary values]")
b_id, _ = execute(INSERT, ("2026-10-22", 1, Decimal("0.01"), "TEST ROW"))
check("smallest valid amount 0.01 accepted", b_id is not None)
execute("DELETE FROM expenses WHERE expense_id = %s", (b_id,))
expect_error("amount above DECIMAL(10,2) range rejected", INSERT,
             ("2026-10-22", 1, Decimal("100000000.00"), "bad",))
check("filter includes both boundary dates (inclusive BETWEEN)",
      len(fetch_all("SELECT * FROM expenses WHERE expense_date BETWEEN %s AND %s",
                    ("2026-09-02", "2026-09-02"))) == 2)

print("\n[Database errors]")
try:
    fetch_all("SELECT * FROM table_that_does_not_exist")
    check("query on missing table raises DatabaseError", False)
except DatabaseError:
    check("query on missing table raises DatabaseError", True)

print(f"\nResult: {passed} passed, {failed} failed")
